package com.sdeal.island

import android.app.Notification
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationService : NotificationListenerService() {

    private var manager: MediaSessionManager? = null
    private val controllers = ArrayList<MediaController>()

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            refreshMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            refreshMedia()
        }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list ->
            setControllers(list)
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            val cn = ComponentName(this, NotificationService::class.java)
            val m = getSystemService(MediaSessionManager::class.java)
            manager = m
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            setControllers(m.getActiveSessions(cn))
        } catch (e: Exception) {
            // ignore
        }
    }

    override fun onListenerDisconnected() {
        try {
            manager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
            // ignore
        }
        setControllers(null)
        super.onListenerDisconnected()
    }

    private fun setControllers(list: List<MediaController>?) {
        for (c in controllers) {
            try {
                c.unregisterCallback(callback)
            } catch (e: Exception) {
                // ignore
            }
        }
        controllers.clear()
        if (list != null) controllers.addAll(list)
        for (c in controllers) {
            try {
                c.registerCallback(callback)
            } catch (e: Exception) {
                // ignore
            }
        }
        refreshMedia()
    }

    private fun refreshMedia() {
        val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val md = c?.metadata
        IslandState.mediaPlaying = c != null
        IslandState.mediaTitle = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        IslandState.mediaArtist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        IslandState.mediaPkg = c?.packageName
        IslandState.changed()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        if (s.packageName == packageName) return
        val n = s.notification ?: return
        val extras = n.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString()

        if (n.category == Notification.CATEGORY_CALL) {
            IslandState.callKey = s.key
            IslandState.callText = title ?: text ?: "Call"
            IslandState.callPkg = s.packageName
            IslandState.changed()
            return
        }
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (title == null && text == null) return

        IslandState.notifTitle = title
        IslandState.notifText = text
        IslandState.notifPkg = s.packageName
        IslandState.notifAt = System.currentTimeMillis()
        IslandState.changed()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        if (s.key == IslandState.callKey) {
            IslandState.callKey = null
            IslandState.callText = null
            IslandState.callPkg = null
            IslandState.changed()
        }
    }
}
