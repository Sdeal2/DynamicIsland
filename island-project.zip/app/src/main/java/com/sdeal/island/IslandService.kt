package com.sdeal.island

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var topRow: LinearLayout
    private lateinit var icon: ImageView
    private lateinit var label: TextView
    private lateinit var appsRow: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams

    private val handler = Handler(Looper.getMainLooper())
    private val tick = Runnable { render() }
    private val collapse = Runnable {
        expanded = false
        render()
    }

    private var expanded = false
    private var attached = false
    private var homePkgs: Set<String> = HashSet()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        homePkgs = findHomePackages()
        buildView()
        IslandState.onChange = { render() }
        render()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        IslandState.onChange = null
        handler.removeCallbacksAndMessages(null)
        try {
            if (attached) wm.removeView(root)
        } catch (e: Exception) {
            // ignore
        }
        attached = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return
        if (homePkgs.contains(pkg)) return
        if (packageManager.getLaunchIntentForPackage(pkg) == null) return
        val list = IslandState.recent
        list.remove(pkg)
        list.add(0, pkg)
        while (list.size > 5) list.removeAt(list.size - 1)
    }

    private fun findHomePackages(): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val out = HashSet<String>()
        for (ri in packageManager.queryIntentActivities(i, 0)) {
            out.add(ri.activityInfo.packageName)
        }
        return out
    }

    private fun buildView() {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        val bg = GradientDrawable()
        bg.setColor(Color.BLACK)
        bg.cornerRadius = dp(22).toFloat()
        root.background = bg
        root.setPadding(dp(14), dp(5), dp(14), dp(5))
        root.setOnClickListener {
            expanded = !expanded
            handler.removeCallbacks(collapse)
            if (expanded) handler.postDelayed(collapse, 6000L)
            render()
        }

        topRow = LinearLayout(this)
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_VERTICAL
        topRow.minimumHeight = dp(24)

        icon = ImageView(this)
        label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        label.maxWidth = dp(220)

        topRow.addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
        val labelLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        labelLp.leftMargin = dp(8)
        topRow.addView(label, labelLp)

        appsRow = LinearLayout(this)
        appsRow.orientation = LinearLayout.HORIZONTAL
        appsRow.gravity = Gravity.CENTER
        appsRow.visibility = View.GONE
        appsRow.setPadding(0, dp(8), 0, dp(4))

        root.addView(topRow)
        root.addView(appsRow)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun iconFor(pkg: String?): Drawable? {
        if (pkg == null) return null
        return try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
    }

    private fun render() {
        if (!::root.isInitialized) return
        handler.removeCallbacks(tick)
        val prefs = getSharedPreferences("island", MODE_PRIVATE)
        val st = IslandState
        val now = System.currentTimeMillis()

        var pkg: String? = null
        var text: String? = null
        if (st.callText != null) {
            pkg = st.callPkg
            text = "📞 " + st.callText
        } else if (now - st.notifAt < 4000L && (st.notifTitle != null || st.notifText != null)) {
            pkg = st.notifPkg
            text = st.notifTitle ?: st.notifText
            handler.postDelayed(tick, 4000L - (now - st.notifAt) + 50L)
        } else if (st.mediaPlaying) {
            pkg = st.mediaPkg
            val t = st.mediaTitle
            val a = st.mediaArtist
            text = if (t != null && a != null) "$t – $a" else (t ?: "♪")
        }

        val d = iconFor(pkg)
        if (d != null) {
            icon.setImageDrawable(d)
            icon.visibility = View.VISIBLE
        } else {
            icon.visibility = View.GONE
        }

        if (text != null) {
            label.text = text
            label.visibility = View.VISIBLE
        } else if (expanded) {
            label.text = if (st.recent.isEmpty()) "अभी कोई ऐप नहीं" else "हाल के ऐप"
            label.visibility = View.VISIBLE
        } else {
            label.visibility = View.GONE
        }

        appsRow.removeAllViews()
        if (expanded) {
            for (p in st.recent) {
                val pd = iconFor(p) ?: continue
                val iv = ImageView(this)
                iv.setImageDrawable(pd)
                iv.setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(p)
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            startActivity(launch)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    expanded = false
                    render()
                }
                val ivLp = LinearLayout.LayoutParams(dp(40), dp(40))
                ivLp.leftMargin = dp(6)
                ivLp.rightMargin = dp(6)
                appsRow.addView(iv, ivLp)
            }
            appsRow.visibility = View.VISIBLE
        } else {
            appsRow.visibility = View.GONE
        }

        root.minimumWidth = dp(prefs.getInt("w", 110))
        lp.x = dp(prefs.getInt("x", 0))
        lp.y = dp(prefs.getInt("y", 8))
        try {
            if (!attached) {
                wm.addView(root, lp)
                attached = true
            } else {
                wm.updateViewLayout(root, lp)
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}
