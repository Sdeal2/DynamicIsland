package com.sdeal.island

import android.os.Handler
import android.os.Looper

/** Shared in-memory state. Nothing here is saved to disk or sent anywhere. */
object IslandState {
    private val main = Handler(Looper.getMainLooper())

    var onChange: (() -> Unit)? = null

    var mediaTitle: String? = null
    var mediaArtist: String? = null
    var mediaPkg: String? = null
    var mediaPlaying: Boolean = false

    var notifTitle: String? = null
    var notifText: String? = null
    var notifPkg: String? = null
    var notifAt: Long = 0L

    var callText: String? = null
    var callKey: String? = null
    var callPkg: String? = null

    val recent: ArrayList<String> = ArrayList()

    fun changed() {
        main.post { onChange?.invoke() }
    }
}
