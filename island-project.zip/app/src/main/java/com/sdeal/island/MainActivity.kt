package com.sdeal.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("island", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad * 2, pad, pad)

        fun addText(s: String, size: Float): TextView {
            val tv = TextView(this)
            tv.text = s
            tv.textSize = size
            tv.setPadding(0, pad / 2, 0, pad / 2)
            col.addView(tv)
            return tv
        }

        fun addButton(s: String, action: () -> Unit) {
            val b = Button(this)
            b.text = s
            b.setOnClickListener { action() }
            col.addView(b)
        }

        fun addSlider(name: String, key: String, lo: Int, hi: Int, def: Int) {
            val tv = addText("$name: ${prefs.getInt(key, def)}", 15f)
            val sb = SeekBar(this)
            sb.max = hi - lo
            sb.progress = prefs.getInt(key, def) - lo
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    val value = v + lo
                    prefs.edit().putInt(key, value).apply()
                    tv.text = "$name: $value"
                    IslandState.changed()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(sb)
        }

        addText("Island", 28f)
        addText(
            "यह ऐप कैमरे के पास एक काला आइलैंड दिखाता है: चल रहा गाना, कॉल, नोटिफ़िकेशन और हाल के ऐप। " +
                "इसमें इंटरनेट की permission नहीं है, इसलिए यह कुछ भी बाहर नहीं भेज सकता।",
            14f
        )

        addText("स्टेप 1", 18f)
        addButton("Accessibility चालू करें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addText("स्टेप 2", 18f)
        addButton("Notification access चालू करें") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addText(
            "अगर ये बटन धूसर (grey) हों, तो नीचे वाला बटन दबाकर ऊपर दाईं तरफ़ ⋮ से " +
                "\"Allow restricted settings\" चुनिए, फिर स्टेप 1 और 2 दोबारा कीजिए।",
            13f
        )
        addButton("App info खोलें") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        }

        addText("स्थिति ठीक करें (कैमरे के हिसाब से)", 18f)
        addSlider("बाएँ-दाएँ", "x", -150, 150, 0)
        addSlider("ऊपर-नीचे", "y", 0, 60, 8)
        addSlider("खाली आइलैंड की चौड़ाई", "w", 60, 200, 110)

        addText("टेस्ट", 18f)
        addButton("टेस्ट नोटिफ़िकेशन दिखाएँ") {
            IslandState.notifTitle = "टेस्ट"
            IslandState.notifText = "आइलैंड चल रहा है"
            IslandState.notifPkg = packageName
            IslandState.notifAt = System.currentTimeMillis()
            IslandState.changed()
        }
        addText("आइलैंड पर टैप करने से हाल के ऐप खुलते हैं।", 13f)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }
}
